#define STACK_SIZE 10

typedef struct {
        int top;
        int stack[STACK_SIZE];
} buffer;

