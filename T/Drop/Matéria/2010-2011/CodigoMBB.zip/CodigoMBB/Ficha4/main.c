#ifdef STACK
#include"stack.h"
#endif
#ifdef QUEUE
#include "queue.h"
#endif
#include "buffer.h"
#include <stdio.h>

int main(void) {
  Buffer b = create();
  int i;
  i = random();
  add(b,i);
  printf("Added: %d\n",i);
  i = random();
  add(b,i);
  printf("Added: %d\n",i);
  i = random();
  add(b,i);
  printf("Added: %d\n",i);
  i = random();
  add(b,i);
  printf("Added: %d\n",i);
  i = random();
  add(b,i);
  printf("Added: %d\n",i);
  while (! empty(b)) {
    retrieve(b,&i);
    printf("Removed %d\n",i);
  }
}
