typedef buffer *Buffer;

Buffer create(void);        // inicia e aloca espaco 
int empty(Buffer);          // testa se esta vazio 
int add(Buffer,int);        // acrescenta elemento 
int next(Buffer, int*);     // proximo a sair 
int retrieve(Buffer, int*);   // remove proximo

