typedef struct node {
	int value;
	struct node *next;
} Node;

typedef struct {
        int size;
        Node *front;
        Node *back;
} buffer;

