#include <stdio.h>
#include <stdlib.h>

#include "fringeA.c"
//#include "fringeB.c"
//#include "fringeC.c"

#define MaxV 1000

#define WHITE 0
#define GRAY  1
#define BLACK 2

typedef struct edge {
  int dest;
  int cost;
  struct edge *next;
} Edge, *Graph [MaxV];



// Shortest Path (Dijkstra)
// devolve o num. ver vértices alcançados a partir de o
int dijkstraSP (Graph g, int o, int p[], int w[], int N) {

  ....
}



//  ==========================================================================
//  o grafo deve estar no ficheiro s
//  o ficheiro deve ter um arco por linha
//  o grafo é orientado
int leGrafoO(Graph g, char *s) {
  Edge *new;
  int i, n=0, x, y, p;
  FILE *fp;

  fp = fopen(s,"r");  
  for (i=0; i<MaxV; i++) g[i] = NULL;
  while (fscanf(fp,"%d %d %d\n", &x, &y, &p) != EOF) { 
      if (x > MaxV-1 || y > MaxV-1) exit(-1);
      if (x > n-1) n = x+1; if (y > n-1) n = y+1;
      new = malloc(sizeof(Edge));
      new->dest = y; new->cost = p; new->next = g[x];
      g[x] = new;
  }
  fclose(fp);
  
  return n;
}

void mostraGrafo(Graph g, int N) {
  Edge *a;
  int i;

  for (i=0; i<N; i++) {
    printf("%d --> ",i);
    for (a=g[i]; a; a=a->next)
      printf("%d(%d) ",a->dest, a->cost);
    printf("\n");
  }
}


int main (int argc, char *argv[]) {
  Graph g2;
  int i, j, x, d, N2, r, pai[MaxV], custo[MaxV];

  if (argc==2) {
  
    // grafo orientado
    N2 = leGrafoO(g2,argv[1]);
    printf("\nGrafo não orientado\n");
    mostraGrafo(g2,N2);
  
    printf("Origem: "); scanf("%d",&x);
    r = dijkstraSP(g2,x,pai,custo,N2);

    // apresenta todos os caminhos
    printf("Caminhos mais curtos com origem em %d\n", x);

....
    
    }
    printf("Total de vértices alcançados = %d\n", r);

    
  }
  
  else printf("Falta ficheiro com o grafo");
}




