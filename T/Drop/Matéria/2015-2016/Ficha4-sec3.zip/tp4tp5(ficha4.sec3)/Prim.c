#include <stdio.h>
#include <stdlib.h>

#include "fringeA.c"
//#include "fringeB.c"
//#include "fringeC.c"

#define MaxV 1000

#define WHITE 0
#define GRAY  1
#define BLACK 2

typedef struct edge {
  int dest;
  int cost;
  struct edge *next;
} Edge, *Graph [MaxV];



// Minimum Spannig Tree (Prim)
// p[]: árvore; w[]: pesos
int primMST (Graph g, int p[], int w[], int N) {
  int i, v, r=0, fsize, col[N];  // r: custo da árvore; fsize: tamanho da orla;
      // col[]: estado (cor) dos vértices. BLACK: na árvore, GRAY: na orla, WHITE: por descobrir
  Fringe f = newFringe (N);       
  Edge *x;
  
  for (i=0;i<N;i++){
    p[i] = -1; col[i] = WHITE;
  }
  col[0] = GRAY; w[0] = 0;
  f = addV (f, 0, 0);      
  fsize=1;
  while (fsize) {
    fsize--;          
    f = nextF(f, &v);   
    col[v] = BLACK;
    r += w[v];  
    for (x=g[v]; x; x = x->next)
      switch (col[x->dest]) {
      case WHITE: col[x->dest] = GRAY;
 	                fsize++;
		              f = addV (f, x->dest, x->cost);
		              w[x->dest] = x->cost; 
                  p[x->dest] = v;
		              break;
      case GRAY : if (w[x->dest] > x->cost) {
		                 f = updateV (f, x->dest, x->cost);
		                 w[x->dest] = x->cost; 
                     p[x->dest] = v;
		              }
                  break;
      default   : break;
      }
  }
  return r;
}


//  ==========================================================================
//  o grafo deve estar no ficheiro s
//  o ficheiro deve ter um arco por linha
//  o grafo é não orientado
int leGrafoNO(Graph g, char *s) {
  Edge *new;
  int i, n=0, x, y, p;
  FILE *fp;

  fp = fopen(s,"r");  
  for (i=0; i<MaxV; i++) g[i] = NULL;
  while (fscanf(fp,"%d %d %d\n", &x, &y, &p) != EOF) { 
      if (x > MaxV-1 || y > MaxV-1) exit(-1);
      if (x > n-1) n = x+1; if (y > n-1) n = y+1;
      new = malloc(sizeof(Edge));
      new->dest = y; new->cost = p; new->next = g[x];
      g[x] = new;
      new = malloc(sizeof(Edge));                    // por ser Não Orientado
      new->dest = x; new->cost = p; new->next = g[y];
      g[y] = new;
  }
  fclose(fp);
  
  return n;
}


void mostraGrafo(Graph g, int N) {
  Edge *a;
  int i;

  for (i=0; i<N; i++) {
    printf("%d --> ",i);
    for (a=g[i]; a; a=a->next)
      printf("%d(%d) ",a->dest, a->cost);
    printf("\n");
  }
}


int main (int argc, char *argv[]) {
  Graph g1;
  int i, j, x, d, N1, r, pai[MaxV], custo[MaxV];

  if (argc==2) {
  
  // grafo não orientado e ligado
    N1 = leGrafoNO(g1,argv[1]);
    printf("\nGrafo não orientado\n");
    mostraGrafo(g1,N1);
  
    r = primMST(g1,pai,custo,N1);
    printf("\nCusto MST = %d\n", r);
    for (i=0; i<N1; i++)
      printf("\t%d<-->%d, peso %d\n", pai[i], i, custo[i]);

  }
  
  else printf("Falta ficheiro com o grafo");
}

  

