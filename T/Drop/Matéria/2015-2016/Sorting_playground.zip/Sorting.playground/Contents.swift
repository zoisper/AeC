//: Playground - noun: a place where people can play

import Cocoa


let a = [3,14,13,9,2,0,8,1,7,4,15,6,5,12,11,10]
let b = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
let c = [15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0]
let d = [1,15,3,13,5,11,7,9,8,6,10,4,12,2,14,0]
let e = [1,2,3,4,3,2,1,2,3,4,3,2,1,2,3,4]

var u:Array<Int>

func aswap(inout A: Array<Int>, i: Int, j :Int)
{
    (A[i], A[j]) = (A[j], A[i])
}



func insertionSort(inout A: Array<Int>) {
    var i, j, key :Int
    for (j = 1; j < A.count; j++) {
        key = A[j]
        i = j-1
        while (i >= 0 && A[i] > key) {
            A[i+1] = A[i]
            i--;
        }
        A[i+1] = key
    }
}

//u=a
//insertionSort(&u)



func merge(inout A:Array<Int>, p :Int, q :Int, r :Int) {
    var i, j, k, n1, n2 :Int
    n1 = q-p+1
    n2 = r-q
    var L :Array<Int> = []
    var R :Array<Int> = []
    for (i=0 ; i<n1 ; i++) { L.append(A[p+i]) }
    for (j=0 ; j<n2 ; j++) { R.append(A[q+j+1]) }
    L.append(2000000) //MAXINT
    R.append(2000000) //MAXINT
    i = 0
    j = 0
    for (k=p ; k<=r ; ) {
        if (L[i] <= R[j]) {
            A[k] = L[i]
            i++
        } else {
            A[k] = R[j]
            j++
        };
        k++
    }
}

func mergeSort (inout A:Array<Int>,  p :Int, r :Int) {
    var q :Int
    if (p < r) {
        q = (p+r)/2;
        mergeSort(&A,p: p,r: q);
        mergeSort(&A,p: q+1,r: r);
        merge(&A,p: p,q: q,r: r);
    }
}


//u=a
//mergeSort(&u, p: 0, r: u.count-1)


func partition (inout A:Array<Int>,  p :Int, r :Int) -> Int {
    var i, j, x :Int
    
    x = A[r]
    i = p-1
    for(j=p; j<r; ) 	{
        if (A[j] <= x) {
            i++
            aswap(&A,i: i,j: j)
        }
        j++
    }
    aswap(&A,i: i+1,j: r)
    return (i+1)
}


func quickSort (inout A:Array<Int>,  p :Int, r :Int) {
    var q :Int
    if (p < r) {
        print(A[p...r])
        q = partition(&A,p: p,r: r)
        quickSort(&A,p: p,r: q-1)
        quickSort(&A,p: q+1,r: r)
    }
}

//u=d
//quickSort(&u, p: 0, r: u.count-1)


func countingSort(A: Array<Int>, inout B: Array<Int>, k: Int) {
    var i, j: Int
    var C = [Int](count: k+1, repeatedValue: 0)
    
    for (j=0 ; j<A.count ; j++) {
        C[A[j]] = C[A[j]]+1
    }
    for (i=1 ; i<=k ; i++) {
        C[i] = C[i]+C[i-1]
    }
    for (j=A.count-1 ; j>=0 ; j--) {
        print(B,"\t",C)
        B[C[A[j]]-1] = A[j];
        C[A[j]] = C[A[j]]-1
    }
}


//u = e
//var v  = [Int](count: u.count, repeatedValue: 0)
//e
//
//countingSort(u, B: &v, k: 1000)



func countingSortIdx(inout B: Array<Int>, k: Int, index: Int) {
    var i, j, x: Int
    var A = B   // aux array, entirely copied as value
    var C = [Int](count: k+1, repeatedValue: 0)
    
    for (j=0 ; j<A.count ; j++) {
        x = (A[j] / index)%10
        C[x] = C[x]+1
    }
    for (i=1 ; i<=k ; i++) {
        C[i] = C[i]+C[i-1]
    }
    for (j=A.count-1 ; j>=0 ; j--) {
        x = (A[j] / index)%10
        B[C[x]-1] = A[j];
        C[x] = C[x]-1
    }
}


func radixSort(inout u: Array<Int>, k: Int) {
    var b :Int

    for (b = 1; b<=k ; b*=10) {
        countingSortIdx(&u, k: k, index: b)
        print(b, u)
    }
}

u = [475,985,123,1598,246,812,444]
// u = [475,985,123,1598,246,812,444,10000]
// u=a

 radixSort(&u, k: 1500)


