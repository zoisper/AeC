#define HASHSIZE    31      // numero primo
#define EMPTY       "" 
#define DELETED     "-"

typedef char KeyType[9];
typedef void *Info;

typedef struct entry {
  KeyType  key;
  Info info;
} Entry;

typedef Entry HashTable[HASHSIZE];

/************** COMMON FUNCS *********/

int Hash(KeyType);               // funcao de hash  
void InitializeTable(HashTable); // inicializa a tabela de hash
void ClearTable(HashTable);      // limpa a tabela de hash

/********LINEAR PROBING*********/

// insere uma nova associacao entre uma chave nova e a restante informacao
int InsertTable_LP(HashTable, KeyType, Info);
// apaga o elemento de chave k da tabela
int DeleteTable_LP(HashTable, KeyType, Info *);
// procura na tabela o elemento de chave k
int  RetrieveTable_LP(HashTable, KeyType, Info *);

/********QUADRATIC PROBING*********/

// insere uma nova associacao entre uma chave nova e a restante informacao
int InsertTable_QP(HashTable, KeyType, Info);
// apaga o elemento de chave k da tabela
int DeleteTable_QP(HashTable, KeyType, Info *);
// procura na tabela o elemento de chave k
int  RetrieveTable_QP(HashTable, KeyType, Info *);
