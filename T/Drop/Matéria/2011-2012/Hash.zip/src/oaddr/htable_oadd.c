#include "hashfunction.h"
#include "htable_oadd.h"
#include <string.h>
#include <stdio.h>

int Hash(KeyType key) {
	ub4 h = hash( (unsigned char *)key, 9, 0);
	return h%HASHSIZE;	
}

void InitializeTable(HashTable t) {
	int i = 0;
	for (i=0;i<HASHSIZE;i++) 
		strncpy(t[i].key,EMPTY,9);
}

void ClearTable(HashTable t) {
	int i = 0;
	for (i=0;i<HASHSIZE;i++) 
		strncpy(t[i].key,EMPTY,9);
}     

/********LINEAR PROBING*********/

int InsertTable_LP(HashTable t, KeyType key, Info data) {
	int h = Hash(key);
	int try = 1;
	while ((try<=HASHSIZE)&&(strncmp(t[h].key,EMPTY,9))&&(strncmp(t[h].key,DELETED,9))) {
        if (!strncmp(t[h].key,key,9)) { break; } // Lida com repetidos
		h = (h + 1) % HASHSIZE;
		try++;
	}
	if (try <= HASHSIZE) {
		strncpy(t[h].key,key,9);
		t[h].info=data;
		return 0;
	}
	else {
		return (-1);
	}
}

int  RetrieveTable_LP(HashTable t, KeyType key,  Info *data) {
	int h = Hash(key);
	int try = 1;
	while ((try<=HASHSIZE)&&(strncmp(t[h].key,EMPTY,9))&&(strncmp(t[h].key,key,9))) {
		h = (h + 1) % HASHSIZE;
		try++;
	}
	if (strncmp(t[h].key,key,9)) {
		return (-1);
	}
	else {
		*data=t[h].info;
		return 0;
	}
}


int DeleteTable_LP(HashTable t, KeyType key, Info *data) {
	int h = Hash(key);
	int try = 1;
	while ((try<=HASHSIZE)&&(strncmp(t[h].key,EMPTY,9))&&(strncmp(t[h].key,key,9))) {
		h = (h + 1) % HASHSIZE;
		try++;
	}
	if (strncmp(t[h].key,key,9)) {
		return (-1);
	}
	else {
		*data=t[h].info;
		strncpy(t[h].key,DELETED,9);
		return 0;
	}    	
}


/********QUADRATIC PROBING*********/

int InsertTable_QP(HashTable t, KeyType key, Info data) {
	int h = Hash(key);
	int try = 1;
	while ((try<HASHSIZE/2)&&(strncmp(t[h].key,EMPTY,9))&&(strncmp(t[h].key,DELETED,9))) {
        if (!strncmp(t[h].key,key,9)) { break; } // Lida com repetidos
		h = (h + 2*try - 1) % HASHSIZE;
		try++;
	}
	if (try <= HASHSIZE) {
		strncpy(t[h].key,key,9);
		t[h].info=data;
		return 0;
	}
	else {
		return (-1);
	}
}

int  RetrieveTable_QP(HashTable t, KeyType key,  Info *data) {
	int h = Hash(key);
	int try = 1;
	while ((try<HASHSIZE/2)&&(strncmp(t[h].key,EMPTY,9))&&(strncmp(t[h].key,key,9))) {
		h = (h + 2*try - 1) % HASHSIZE;
		try++;
	}
	if (strncmp(t[h].key,key,9)) {
		return (-1);
	}
	else {
		*data=t[h].info;
		return 0;
	}
}

int DeleteTable_QP(HashTable t, KeyType key, Info *data) {
	int h = Hash(key);
	int try = 1;
	while ((try<HASHSIZE/2)&&(strncmp(t[h].key,EMPTY,9))&&(strncmp(t[h].key,key,9))) {
		h = (h + 2*try - 1) % HASHSIZE;
		try++;
	}
	if (strncmp(t[h].key,key,9)) {
		return (-1);
	}
	else {
		*data=t[h].info;
		strncpy(t[h].key,DELETED,9);
		return 0;
	}    	
}
