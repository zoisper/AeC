#include "htable_oadd.h"
#include <stdio.h>
#include <stdlib.h>

int main(void) {
	int *newval,res;
	HashTable tableLP, tableQP;
	
	InitializeTable(tableLP);
	
	newval=(int*)malloc(sizeof(int));
	*newval = 1;
	InsertTable_LP(tableLP,"key1",(Info*)newval);

	newval=(int*)malloc(sizeof(int));
	*newval = 2;
	InsertTable_LP(tableLP,"key2",(Info*)newval);

	newval=(int*)malloc(sizeof(int));
	*newval = 3;
	InsertTable_LP(tableLP,"key3",(Info*)newval);

	newval=(int*)malloc(sizeof(int));
	*newval = 4;
	InsertTable_LP(tableLP,"key4",(Info*)newval);
	
	res=RetrieveTable_LP(tableLP, "key2",  (void**)&newval);
    if (res)
	   printf("Retrieve Error: %s\n","key2");
    else
		printf("Retrieve %s: %d\n","key2",*newval);

	res=DeleteTable_LP(tableLP, "key2",  (void**)&newval);
    if (res)
	   printf("Delete Error: %s\n","key2");
    else
		printf("Deleted %s: %d\n","key2",*newval);
	free(newval);

	res=RetrieveTable_LP(tableLP, "key2",  (void**)&newval);
    if (res)
	   printf("Retrieve Error: %s\n","key2");
    else
		printf("Retrieve %s: %d\n","key2",*newval);

	res=RetrieveTable_LP(tableLP, "key1",  (void**)&newval);
    if (res)
	   printf("Retrieve Error: %s\n","key1");
    else
		printf("Retrieve %s: %d\n","key1",*newval);

	res=RetrieveTable_LP(tableLP, "key4",  (void**)&newval);
    if (res)
	   printf("Retrieve Error: %s\n","key4");
    else
		printf("Retrieve %s: %d\n","key4",*newval);

	InitializeTable(tableQP);
	
	newval=(int*)malloc(sizeof(int));
	*newval = 1;
	InsertTable_QP(tableQP,"key1",(Info*)newval);

	newval=(int*)malloc(sizeof(int));
	*newval = 2;
	InsertTable_QP(tableQP,"key2",(Info*)newval);

	newval=(int*)malloc(sizeof(int));
	*newval = 3;
	InsertTable_QP(tableQP,"key3",(Info*)newval);
	
	newval=(int*)malloc(sizeof(int));
	*newval = 4;
	InsertTable_QP(tableQP,"key4",(Info*)newval);
	
	res=RetrieveTable_QP(tableQP, "key2",  (void**)&newval);
    if (res)
	   printf("Retrieve Error: %s\n","key2");
    else
		printf("Retrieve %s: %d\n","key",*newval);

	res=DeleteTable_QP(tableQP, "key2",  (void**)&newval);
    if (res)
	   printf("Delete Error: %s\n","key2");
    else
		printf("Deleted %s: %d\n","key2",*newval);
	free(newval);

	res=RetrieveTable_QP(tableQP, "key2",  (void**)&newval);
    if (res)
	   printf("Retrieve Error: %s\n","key2");
    else
		printf("Retrieve %s: %d\n","key2",*newval);
		
	res=RetrieveTable_QP(tableQP, "key1",  (void**)&newval);
    if (res)
	   printf("Retrieve Error: %s\n","key1");
    else
		printf("Retrieve %s: %d\n","key1",*newval);

	res=RetrieveTable_QP(tableQP, "key4",  (void**)&newval);
    if (res)
	   printf("Retrieve Error: %s\n","key4");
    else
		printf("Retrieve %s: %d\n","key4",*newval);


	return 0;
		
}
