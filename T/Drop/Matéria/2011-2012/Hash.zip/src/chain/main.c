#include "htable_chain.h"
#include <stdio.h>
#include <stdlib.h>

int main(void) {
	int *newval,res;
	HashTable table;
	
	InitializeTable(table);
	
	newval=(int*)malloc(sizeof(int));
	*newval = 1;
	res=InsertTable(table,"key1",(Info*)newval);
    if (res)
	   printf("Insert Error: %s\n","key1");

	newval=(int*)malloc(sizeof(int));
	*newval = 2;
	InsertTable(table,"key2",(Info*)newval);
    if (res)
	   printf("Insert Error: %s\n","key2");

	newval=(int*)malloc(sizeof(int));
	*newval = 3;
	InsertTable(table,"key3",(Info*)newval);
	if (res)
	   printf("Insert Error: %s\n","key3");
   

	newval=(int*)malloc(sizeof(int));
	*newval = 4;
	InsertTable(table,"key4",(Info*)newval);
	if (res)
	   printf("Insert Error: %s\n","key4");
    
	
	res=RetrieveTable(table, "key2",  (void**)&newval);
    if (res)
	   printf("Retrieve Error: %s\n","key2");
    else
		printf("Retrieve %s: %d\n","key2",*newval);

	res=DeleteTable(table, "key2",  (void**)&newval);
    if (res)
	   printf("Delete Error: %s\n","key2");
    else
		printf("Deleted %s: %d\n","key2",*newval);
	free(newval);

	res=RetrieveTable(table, "key2",  (void**)&newval);
    if (res)
	   printf("Retrieve Error: %s\n","key2");
    else
		printf("Retrieve %s: %d\n","key2",*newval);

	res=RetrieveTable(table, "key1",  (void**)&newval);
    if (res)
	   printf("Retrieve Error: %s\n","key1");
    else
		printf("Retrieve %s: %d\n","key1",*newval);

	res=RetrieveTable(table, "key4",  (void**)&newval);
    if (res)
	   printf("Retrieve Error: %s\n","key4");
    else
		printf("Retrieve %s: %d\n","key4",*newval);

	return 0;
		
}
