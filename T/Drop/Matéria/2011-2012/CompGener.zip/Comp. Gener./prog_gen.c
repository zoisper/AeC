#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "prog_gen.h"

int compara (void *a,void *b){
	My_Data *aa,*bb;
	
	aa=(My_Data*)a;
	bb=(My_Data*)b;
	
	if( (strcmp(aa->teste,bb->teste) < 0)) return -1;
	if(	(strcmp(aa->teste,bb->teste) == 0 )) return 0;
	
	return 1;
}


void imprime (void* info){
	My_Data* d=(My_Data*)info;
	printf("\nTeste - %s   Numero - %d   Idade - %d   Taxa - %f\n",d->teste,d->num,d->idade,d->taxa);
}


int init(int size, int (*compare)(void*,void*)){
	int handle,i;
	
	//discover free  position on control
	for(i=0;i<next_LL;i++)
	{
		if(control[i].sizeofdata==-1)
		{
			handle=i;
			break;
		}
	}
	if(i==next_LL)
	{
		if(next_LL < NBR_LL)  //Verifica se nao estamos no numero maximo de elementos
		{
			handle=next_LL;
			next_LL++;
		}
		else
		{
			return -1;
		}	
	}
	//init control
	control[handle].sizeofdata=size;
	control[handle].compare=compare;
	control[handle].root=NULL;
	return handle;
}


int insert(int handle, void* data){
	//void *data_ptr;
	Node *n,*act,*prev;
	
	
	
	//Verify  the  handle ia valid
	if(!valid_handle(handle)) return 0;
	
	
	n=(Node*)malloc(sizeof(Node));
	if(!n) return 0;
	n->data = data;
	
	//search for insertion point
	act=control[handle].root;
	prev=NULL;
	while((act !=NULL) && (control[handle].compare(n->data,act->data)>0))
	{
		prev=act;
		act=(Node*)act->next;
	}
	if (prev==NULL)
	{
		control[handle].root=n; //insert on 1st position
		
	}
	else
	{
		prev->next=(Node*)n;
	}
	n->next=(Node*)act;
	
	
	//imprime(n->data);
	return 1;
}

int delete(int handle, void* data){
	Node *act,*prev;
	int cmp;
	
	//Verify  the  handle ia valid
	if(!valid_handle(handle)) return 0;
	
	prev=NULL;
	act=control[handle].root;
	
	while(act!=NULL)
	{
		cmp=control[handle].compare(data,act->data);
		if(cmp>0)  //Procede on the list
		{
			prev=act;
			act=(Node*)act->next;
		}
		else if(cmp==0)		//Found!!
		{
			if(prev==NULL)		//1st Element
			{
				control[handle].root=(Node*)act->next;
			}
			else
			{
				prev->next=act->next;
			}
			free(act->data);
			free(act);
			return 1;
		}
		else      //not found
		{
			return 0;
		}
	}
		
	return 0;	
}


//searches for data whose key you value is given  on the 2nd parameter
//if founds copies  the asoociated data for teh 2nd parameter
int search(int handle, void* data){
	Node *act;
	int cmp;
	
	//Verify the handle is valid
	if(!valid_handle(handle)) return 0;
	
	act=control[handle].root;
	
	while(act!=NULL)
	{
		cmp=control[handle].compare(data,act->data);
		if(cmp>0)  //Procede on the list
		{
			act=(Node*)act->next;
		}
		else if(cmp==0)		//Found!!
		{
			memcpy(data,act->data,control[handle].sizeofdata);
			return 1;
		}
		else    //not found!!
		{
			return 0;
		}
	}
	return 0;
}

int clean(int handle){
	Node *act,*rem;
	
	//Verify  the  handle ia valid
	if(!valid_handle(handle)) return 0;
	
	act=control[handle].root;
	while(act!=NULL)
	{
		free(act->data);
		rem=act;
		act=(Node*)act->next;
		free(rem);
	}
	control[handle].root=NULL;
	control[handle].sizeofdata=-1;
	return -1;
}


void cria_data(int LL,char *teste, int num,int idade,float taxa){
	My_Data *d=(My_Data*)malloc(sizeof(My_Data));
	char t[30];
	
	strncpy(d->teste,strncpy(t,teste,30),30);
	d->num=num;
	d->idade=idade;
	d->taxa=taxa;
	printf("LL - %d\n",LL);
	insert(LL,d);
}


int apagar_elemento(int LL,void* info){
	My_Data* d=(My_Data*)info;
	char *t=d->teste;
	if(delete(LL,info))
		printf("Elemento %s Removido!\n",t);
	else
		printf("Elemento %s Nao Removido!\n",t);	
	return 0;
}


int main(void) {
	My_Data d;
	int LL,i;
	char key[30];
	Node *aux,*aux2;//,*aux3;
	/*Inicializacao da Lista*/
	LL=init(sizeof(My_Data),&compara);
	if(LL==-1)
	{
		fprintf(stderr,"ERROR!\n");
		return 0;
	}
	/*Inserir um  Elemento*/
	
	cria_data(LL,"Antonio",10,100,10.5);
	cria_data(LL,"Manuel",20,200,20.5);
	cria_data(LL,"Bruno",30,300,30.5);
	
	aux=control[0].root;
	aux2=aux->next;
	//aux3=aux2->next;
	apagar_elemento(LL,aux2->data);
	for(i=0;i<2;i++)
	{
		for(aux=control[i].root;aux;aux=aux->next)
		{
			imprime(aux->data);
		}
	}
	printf("Intruduza Key: ");
	scanf("%s",key);
	strncpy(d.teste,key,30);
	search(LL,&d);
	
	printf("\nNumero - %d   Idade - %d   Taxa - %f\n",d.num,d.idade,d.taxa);

	return 0;
}

	/*aux=control[0].root;
	aux2=aux->next;
	aux3=aux2->next;
	imprime(aux->data);
	imprime(aux2->data);
	imprime(aux3->data);
	//apagar_elemento(LL,aux2->data);
	for(i=0;i<2;i++)
	{
		for(aux=control[i].root;aux;aux=aux->next)
		{
			imprime(aux->data);
		}
	}
	aux=control[0].root;
	aux2=aux->next;
	aux3=aux2->next;
	apagar_elemento(LL,aux3->data);
	for(i=0;i<2;i++)
	{
		for(aux=control[i].root;aux;aux=aux->next)
		{
			imprime(aux->data);
		}
	}
*/
