


typedef struct my_data{
	int num;
	int idade;
	float taxa;
}My_Data;

//Data Type for each node
typedef struct node{
	void *data;
	void *next;
}Node;

//Data Type for LL Control
typedef struct ll_control{
	int sizeofdata;
	int (*compare)(void*,void*);
	Node *root;
}LL_control;


//maximum nbr of LL
#define NBR_LL 10

//data for controling each LL
static LL_control control[NBR_LL];

//free pos in LL_control
static int next_LL=0;

//verify  whether a handle  is valid
static int valid_handle(int h){
	if (h>=next_LL) return 0;
	if(control[h].sizeofdata==-1) return 0;
	return 1;
}
