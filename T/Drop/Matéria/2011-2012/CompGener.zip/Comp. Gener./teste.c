#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef void *Info;

typedef struct teste{
	int x;
	int y;
}Teste;


int test(Info i){
	
	printf("%d  %d",(Teste*)->x,(Teste*)->y);
	return 0;
}


int main(void){
	Teste *t=(Teste*)malloc(sizeof(Teste));
	
	t->x=10;
	t->y=20;
	test((Info*)t);
	getchar();
	return 0;
}
